package com.mdsystemapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MdSystemApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
